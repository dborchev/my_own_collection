# Ansible Collection - dborchev.yandex_cloud_elk

This is an etude in creating an Ansible module.


Please refer to the [homeworks repository](https://github.com/dborchev/devops-netology/blob/main/08-ansible-06-module/README.md) for details.



The collection contains a single module `my_own_module` that puts `content` to a text file at `path`.


The `single_task_role` contains a trivial test of this module.
